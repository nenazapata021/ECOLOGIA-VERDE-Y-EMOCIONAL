<html>
  <body>
    <head>
      <usuario>
    <br>nombre        cedula            estado</br>
    <br>Esteban       1254980436        soltero</br>
    <br>Lucía         10258284          casada</br>
    <br>Mateo         16072419          noviasgo</br>
    <br>Sofía         1007234435        noviasgo</br>
    <br>Daniel        16075877          casado</br>
    <br>Martina       24335463          soltera</br>
    <br>Alejandro     24347523          noviasgo</br>
    <br>María         30304907          soltera</br>
    <br>Hugo          10258284          soltero</br>
    <br>Juliana       16078105          soltera</br>
    <br>Leo           16079995          noviasgo</br>
    <br>Edna          1023522196        soltera</br>
      </usuario>
    </head>
  </body>
</html>