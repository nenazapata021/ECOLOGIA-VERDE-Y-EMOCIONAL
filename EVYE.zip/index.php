<html>
  <head>
    <title>ECOLOGIA VERDE Y EMOCIONAL</title>
  </head>
  <body>
    <?php echo '<h1><p>Edna Castañeda Zapata.
                  <br>Yurley Salas Durango.</br></h1>
    <br><h1>Colegio: Fe y Alegria Aures.</h1>
    </p>'; ?> 
 <img src="img/logo2.jpg">  <img src="img/logo9.jpg"> 
  
  
  </body>
</html>