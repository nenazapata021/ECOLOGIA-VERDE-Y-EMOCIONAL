<?
$host="bgofsfb2rgitdfywupoo-mysql.services.clever-cloud.com";
$bd="bgofsfb2rgitdfywupoo";
$user="ujhqdjkd2oo4flde";
$pwd="Kbck43jxpCt0YfhWi7Il";
$con=mysqli_connect($host,$user,$pwd,$bd) or die("Problemas enla conexión");
?>